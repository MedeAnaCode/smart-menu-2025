import React from 'react';

function Sidebar () {
    return (
        <section className="functional-page__sidebar sidebar">
            <p>
                НЕДЕЛИ
            </p>
            <p>
                РЕЦЕПТЫ ЭТОЙ НЕДЕЛИ
            </p>
            <p>
                СПИСОК ПРОДУКТОВ
            </p>
        </section>
    );
}

export default Sidebar;
