import React from 'react';

function Menu () {

    return (
        <section className="functional-page__content">
            MENU MENU MENU MENU MENU MENUMENU MENU MENUMENU MENU MENUMENU MENU MENUMENU MENU MENUMENU MENU MENUMENU MENU MENUMENU MENU MENUMENU MENU MENUMENU MENU MENUMENU MENU MENUMENU MENU MENUMENU MENU MENUMENU MENU MENUMENU MENU MENUMENU MENU MENU

            Posuere pulvinar luctus auctor enim nec per augue eget. Praesent pretium lectus lorem facilisi lacinia sollicitudin quisque. Hac mus vel fames massa rutrum velit faucibus senectus bibendum. Nascetur aenean habitant sagittis mattis proin congue? Sit turpis sollicitudin nisi, pharetra egestas inceptos at lectus. Nec porta commodo leo commodo viverra vel etiam platea nec. Urna sollicitudin odio taciti facilisi condimentum iaculis purus.

            Primis pulvinar curabitur pulvinar lobortis, taciti id leo ipsum. Magna ultrices conubia dis massa quam purus vel dis. Gravida augue iaculis risus platea sagittis consequat nascetur congue. Nullam faucibus cras facilisis est phasellus vestibulum. Maecenas massa curabitur elit feugiat aenean commodo mollis metus finibus. Id varius interdum tempus pretium suspendisse faucibus consequat molestie erat. Convallis eget imperdiet sociosqu volutpat massa adipiscing velit auctor. Scelerisque penatibus laoreet consectetur varius convallis. Enim leo potenti; habitant aptent consequat eget?

            Commodo feugiat odio felis felis elit molestie. Orci tristique parturient facilisi nam vitae suspendisse nunc. Venenatis metus bibendum convallis ullamcorper penatibus a. Cubilia tincidunt cras penatibus torquent sodales elit. Nunc penatibus ullamcorper a suscipit himenaeos laoreet dapibus. Accumsan eget bibendum risus; per imperdiet ad pharetra. Curae libero et elementum, integer sagittis mi fusce. Fringilla gravida rutrum nec hac accumsan bibendum hendrerit. Aliquet eleifend laoreet vehicula nec bibendum accumsan purus leo. Molestie vulputate habitant fringilla pharetra odio placerat ullamcorper dui.

            Pharetra phasellus placerat iaculis sapien, purus at. Fusce augue aliquam finibus primis, tincidunt diam egestas. Malesuada iaculis vehicula facilisi lectus ultricies duis rutrum donec potenti. Commodo mi himenaeos efficitur vitae velit elit ipsum lectus. Amet convallis posuere adipiscing hac ultricies laoreet iaculis. Iaculis fermentum et bibendum maximus dignissim justo nunc malesuada. Ridiculus magnis metus dignissim nam morbi, lobortis habitasse praesent felis. Congue et auctor platea habitant bibendum dui urna condimentum. Metus mus donec magnis lacinia fusce ac penatibus. Litora habitant fringilla risus hendrerit, tellus habitant duis ut.
        </section>
    );
}

export default Menu;
